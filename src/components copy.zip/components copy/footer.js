import Navbar from "react-bootstrap/Navbar";

function footer() {
    return(
        <>
        <Navbar bg="dark" variant="dark">
            <Navbar.Brand>&copy; All rights reserved</Navbar.Brand>
            </Navbar>
            </>
    )

}

export default footer;